<h2>Convert zip file to 3gp file</h2>
<form class="form-horizontal" action="xuly.php" method="GET">
<div class="form-group">
  <label class="control-label col-sm-2" for="">Download file 3gp:</label>
  <div class="col-sm-10">
	<a href="t1.3gp" target="_blank">t1.3gp</a>
  </div>
</div>
<div class="form-group">
  <label class="control-label col-sm-2" for="f3gpfolder">t1.3gp folder:</label>
  <div class="col-sm-10">
	<input type="text" class="form-control" id="f3gpfolder" placeholder="C:\Users\Do Thanh Long\Downloads" name="f3gpfolder" value="" required>
  </div>
</div>
<div class="form-group">
  <label class="control-label col-sm-2" for="fzipfolder">zip folder:</label>
  <div class="col-sm-10">
	<input type="text" class="form-control" id="fzipfolder" placeholder="D:\tmp\output" name="fzipfolder" required>
  </div>
</div>
<div class="form-group">        
  <div class="col-sm-offset-2 col-sm-10">
	<button name="submit_genbatch" id="submit_genbatch" type="submit" class="btn btn-default">Submit</button>
  </div>
</div>
</form>